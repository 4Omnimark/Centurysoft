﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmnimarkAmazonWeb.Models
{
    public static class ConstantData
    {
        public const string ED = "ED";
        public const string EM = "EM";
        public const string DC = "DC";
        public const string DI = "DI";
        public const string SportingGoods = "SportingGoods";
        public const string Toys = "Toys";
        public const string Beauty = "Beauty";
        public const string Baby = "Baby";
        public const string Watches = "Watches";
        public const string Jewelry = "Jewelry";
        public const string HomeandKitchen = "HomeAndKitchen";


        
    }
}