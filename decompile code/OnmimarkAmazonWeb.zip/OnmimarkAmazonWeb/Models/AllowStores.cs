﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmnimarkAmazonWeb.Models
{
    public class AllowStores
    {
        public string storename { get; set; }
        public string Selling { get; set; }
        
    }
}