﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmnimarkAmazonWeb.Models
{
    public class ExportStatusModel
    {
        public string FileName { get; set; }
        public string Category { get; set; }
        public string PriceValue { get; set; }

    }
}