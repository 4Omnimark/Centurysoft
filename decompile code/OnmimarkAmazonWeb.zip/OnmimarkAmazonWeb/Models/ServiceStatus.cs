﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmnimarkAmazonWeb.Models
{
    public class ServiceStatus
    {
        public string servicenm { get; set; }
        

    }
}